$(document).ready(function() {
    $('#jenis').select2({
        placeholder: "-- Pilih Jenis --",
        allowClear: false,
        width: '100%'
    });
});