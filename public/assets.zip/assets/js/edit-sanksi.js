$(document).ready(function() {
    $('#jenis').select2({
        placeholder: "-- Pilih Jenis --",
        width: '100%'
    });
});